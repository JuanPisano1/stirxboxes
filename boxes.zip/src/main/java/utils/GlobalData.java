package utils;

public class GlobalData {
    public static String nroSerieGPS = "";
    public static String nroSerieVLU = "";
    public static String vehiculoDominio = "";
    public static String nroSolicitud = "";
    public static String nroDeDocumento = "";
    public static String chasis = "CHA_"+nroSolicitud;
    public static String motor = "MOT_"+nroSolicitud;
}
