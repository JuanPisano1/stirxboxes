package database.business;

public enum Servicio {
    STRIX_AUTO,
    STRIX_MOTO,
    STRIX_FLOTAS,
    RECUPERO,
    ESTANDAR
}
