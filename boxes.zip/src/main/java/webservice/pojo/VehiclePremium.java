package webservice.pojo;

public class VehiclePremium extends Services {
    private Boolean enabled;

    public Boolean getEnabled() {
        return enabled;
    }

    public VehiclePremium setEnabled(Boolean enabled) {
        this.enabled = enabled;
        return this;
    }
}