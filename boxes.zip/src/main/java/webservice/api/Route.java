package webservice.api;

public class Route {
    public static final String ACCOUNT = "/accounts";
    public static final String THINGS = "/v1.5/things";

    public static final String AUTH="/oauth/token";
}



