package steps;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import utils.driverManager.BrowserManager;

public class BaseStep extends BrowserManager {

}
